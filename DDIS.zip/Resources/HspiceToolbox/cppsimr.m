system('tcsh c:\cygwin\homes\perrott\CppSim\bin_win\cppsimr');
