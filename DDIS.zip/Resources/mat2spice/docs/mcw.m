% CODE GENERATOR FOR FILE: /users/micas/pnuyts/mat2spice_package/mat2spice/docs/mat2spice2.m2html
% CREATED:                 18-Oct-2010 10:20:38

param_mcw{1} = param;
